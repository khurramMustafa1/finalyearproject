import 'package:flutter/material.dart';
class setting extends StatelessWidget {
  const setting({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        leading: IconButton(onPressed: (){}, icon: Icon(Icons.arrow_back)),
      ),
     body: Padding(
       padding: const EdgeInsets.all(8.0),
       child: SingleChildScrollView(
         child: Column(
           children: [
             Row(
               children: [
                 Flexible(
                   child: TextField(
                     decoration: InputDecoration(
                       filled: true,
                       fillColor: const Color(0xffF1F1F1).withOpacity(0.4),
                       enabledBorder: OutlineInputBorder(
                         borderSide: const BorderSide(color: Colors.black),
                         borderRadius: BorderRadius.circular(50),
                       ),
                       focusedBorder: OutlineInputBorder(
                         borderSide: const BorderSide(color: Colors.black),
                       ),
                       hintText: "Discover your next destination",
                       prefixIcon: const Icon(Icons.search),
                     ),
                   ),
                 ),
                 const SizedBox(width: 8),
                 CircleAvatar(
                   radius: 25,
                   backgroundImage: AssetImage('assets/images/profile2.png'),
                 ),
               ],
             ),
             SizedBox(height: 18,),
             Center(
               child: Text("Tools",style: TextStyle(color: Color(0xff0D4858)
                   ,fontSize: 24,fontWeight: FontWeight.w900),),
             ),
             SizedBox(height: 18,),
             Row(
               children: [
                 Column(
                   children: [
                     Padding(
                       padding: const EdgeInsets.symmetric(horizontal: 42),
                       child: Container(
                         width: 110,
                         height: 85,
                         decoration: BoxDecoration(
                           color: Color(0xffADD2DC),
                           borderRadius: BorderRadius.circular(10),
                         ),
                         child: TextButton(onPressed: (){}, child:
                         Image.asset("assets/images/Vector.png",height: 55,width: 63,)
                         )
                       ),
                     ),
                     SizedBox(height: 7,),
                     Text("Weather Forecast",style: TextStyle(color:
                     Color(0xff0D4858),fontWeight: FontWeight.w900,fontSize: 16),),
                   ],
                 ),
                 SizedBox(width: 2,),
                 Column(
                   children: [
                     Padding(
                       padding: const EdgeInsets.symmetric(horizontal: 42),
                       child: Container(
                           width: 110,
                           height: 85,
                           decoration: BoxDecoration(
                             color: Color(0xffADD2DC),
                             borderRadius: BorderRadius.circular(10),
                           ),
                           child: TextButton(onPressed: (){}, child:
                           Image.asset("assets/images/travel.png",height: 55,width: 63,)
                           )
                       ),
                     ),
                     SizedBox(height: 7,),
                     Text("Travel Buddy",style: TextStyle(color:
                     Color(0xff0D4858),fontWeight: FontWeight.w900,fontSize: 16),),
                   ],
                 )
               ],
             ),
             SizedBox(height: 18,),
             Row(
               children: [
                 Column(
                   children: [
                     Padding(
                       padding: const EdgeInsets.symmetric(horizontal: 42),
                       child: Container(
                           width: 110,
                           height: 85,
                           decoration: BoxDecoration(
                             color: Color(0xffADD2DC),
                             borderRadius: BorderRadius.circular(10),
                           ),
                           child: TextButton(onPressed: (){}, child:
                           Image.asset("assets/images/reminder.png",height: 55,width: 63,)
                           )
                       ),
                     ),
                     SizedBox(height: 7,),
                     Text("Reminder",style: TextStyle(color:
                     Color(0xff0D4858),fontWeight: FontWeight.w900,fontSize: 16),),
                   ],
                 ),
                 SizedBox(width: 2,),
                 Column(
                   children: [
                     Padding(
                       padding: const EdgeInsets.symmetric(horizontal: 42),
                       child: Container(
                           width: 110,
                           height: 85,
                           decoration: BoxDecoration(
                             color: Color(0xffADD2DC),
                             borderRadius: BorderRadius.circular(10),
                           ),
                           child: TextButton(onPressed: (){}, child:
                           Image.asset("assets/images/packing.png",height: 55,width: 63,)
                           )
                       ),
                     ),
                     SizedBox(height: 7,),
                     Text("Packing list",style: TextStyle(color:
                     Color(0xff0D4858),fontWeight: FontWeight.w900,fontSize: 16),),
                   ],
                 )
               ],
             ),
             SizedBox(height: 18,),
             Row(
               children: [
                 Column(
                   children: [
                     Padding(
                       padding: const EdgeInsets.symmetric(horizontal: 42),
                       child: Container(
                           width: 110,
                           height: 85,
                           decoration: BoxDecoration(
                             color: Color(0xffADD2DC),
                             borderRadius: BorderRadius.circular(10),
                           ),
                           child: TextButton(onPressed: (){}, child:
                           Image.asset("assets/images/space.png",height: 55,width: 63,)
                           )
                       ),
                     ),
                     SizedBox(height: 7,),
                     Text("Space Sharing",style: TextStyle(color:
                     Color(0xff0D4858),fontWeight: FontWeight.w900,fontSize: 16),),
                   ],
                 ),
                 SizedBox(width: 2,),
                 Column(
                   children: [
                     Padding(
                       padding: const EdgeInsets.symmetric(horizontal: 42),
                       child: Container(
                           width: 110,
                           height: 85,
                           decoration: BoxDecoration(
                             color: Color(0xffADD2DC),
                             borderRadius: BorderRadius.circular(10),
                           ),
                           child: TextButton(onPressed: (){}, child:
                           Image.asset("assets/images/location.png",height: 55,width: 63,)
                           )
                       ),
                     ),
                     SizedBox(height: 7,),
                     Text("Google Maps",style: TextStyle(color:
                     Color(0xff0D4858),fontWeight: FontWeight.bold,fontSize: 16),),
                   ],
                 )
               ],
             ),
             SizedBox(height: 18,),
             Row(
               children: [
                 Column(
                   children: [
                     Padding(
                       padding: const EdgeInsets.symmetric(horizontal: 42),
                       child: Container(
                           width: 110,
                           height: 85,
                           decoration: BoxDecoration(
                             color: Color(0xffADD2DC),
                             borderRadius: BorderRadius.circular(10),
                           ),
                           child: TextButton(onPressed: (){}, child:
                           Image.asset("assets/images/safety.png",height: 55,width: 63,)
                           )
                       ),
                     ),
                     SizedBox(height: 7,),
                     Text("Safety alerts",style: TextStyle(color:
                     Color(0xff0D4858),fontWeight: FontWeight.w900,fontSize: 16),),
                   ],
                 ),
                 SizedBox(width: 2,),
                 Column(
                   children: [
                     Padding(
                       padding: const EdgeInsets.symmetric(horizontal: 42),
                       child: Container(
                           width: 110,
                           height: 85,
                           decoration: BoxDecoration(
                             color: Color(0xffADD2DC),
                             borderRadius: BorderRadius.circular(10),
                           ),
                           child: TextButton(onPressed: (){}, child:
                           Image.asset("assets/images/gallery.png",height: 55,width: 63,)
                           )
                       ),
                     ),
                     SizedBox(height: 7,),
                     Text("Photos Gallery",style: TextStyle(color:
                     Color(0xff0D4858),fontWeight: FontWeight.bold,fontSize: 16),),
                   ],
                 )
               ],
             ),
           ],
         ),
       ),
     ),
      bottomNavigationBar: BottomNavigationBar(items: [
        BottomNavigationBarItem(icon: IconButton(onPressed: (){}, icon: Icon(Icons.home,color: Color(0xff0D4858),),),label: "",),
        BottomNavigationBarItem(icon: IconButton(onPressed: (){}, icon: Icon(Icons.settings,color: Color(0xff0D4858),)),label: ""),
        BottomNavigationBarItem(icon: IconButton(onPressed: (){}, icon: Icon(Icons.add,color: Color(0xff0D4858),)),label: ""),
        BottomNavigationBarItem(icon: IconButton(onPressed: (){}, icon: Icon(Icons.message,color: Color(0xff0D4858),)),label: ""),
        BottomNavigationBarItem(icon: IconButton(onPressed: (){}, icon: Icon(Icons.menu,color: Color(0xff0D4858),)),label: ""),

      ]),
    );
  }
}
