class reminderlist{
  final String image;
  final String title;
  final String description;
  final String actionButton1;
  final String actionButton2;
  final String actionButton3;
  reminderlist({required this.image,required this.title,
    required this.actionButton1,required this.actionButton2,
    required this.actionButton3,required this.description});
}