import 'package:flutter/cupertino.dart';
class buddieslist{
  final title;
  final image;
  final Icon;
   buddieslist({required this.title,required this.image,required this.Icon});
}