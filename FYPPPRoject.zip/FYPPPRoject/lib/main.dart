import 'package:flutter/material.dart';
import 'package:fyppproject/Login.dart';
import 'package:fyppproject/Register.dart';
import 'package:fyppproject/Reminder.dart';
import 'package:fyppproject/Verify.dart';
import 'package:fyppproject/budget.dart';
import 'package:fyppproject/clothes.dart';
import 'package:fyppproject/festivals.dart';
import 'package:fyppproject/food.dart';
import 'package:fyppproject/homepage.dart';
import 'package:fyppproject/hotel.dart';
import 'package:fyppproject/loginsucessfull.dart';
import 'package:fyppproject/overview.dart';
import 'package:fyppproject/overview2.dart';
import 'package:fyppproject/packinglist.dart';
import 'package:fyppproject/packinglist2.dart';
import 'package:fyppproject/planetrip.dart';
import 'package:fyppproject/review.dart';
import 'package:fyppproject/setting.dart';
import 'package:fyppproject/spaceshare.dart';
import 'package:fyppproject/travelbuddy.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home:food()
    );
  }
}
