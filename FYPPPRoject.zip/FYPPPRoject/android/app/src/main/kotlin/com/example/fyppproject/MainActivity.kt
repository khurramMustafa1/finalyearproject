package com.example.fyppproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
